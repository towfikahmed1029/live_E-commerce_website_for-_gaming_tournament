from django.views.generic.list import ListView
from leaderboard.models import Pubg, Codm, Ff

# Create your views here.
class pubglist(ListView):
    model = Pubg
class codmlist(ListView):
    model = Codm
class fflist(ListView):
    model = Ff