from django.urls import path
from leaderboard.views import pubglist, codmlist, fflist
app_name = 'leaderboard'
urlpatterns = [
    path('pubg/', pubglist.as_view(template_name= 'leaderboard/index.html'), name = 'pubg'),
    path('codm/', codmlist.as_view(template_name= 'leaderboard/index2.html'), name = 'cod'),
    path('free_fire/', fflist.as_view(template_name= 'leaderboard/index3.html'), name = 'ff'),
    
]