from django.contrib import admin
from django.urls import path, include
from django.conf import settings
from django.contrib.auth import views as auth_views
from django.contrib.staticfiles.urls import static, staticfiles_urlpatterns

app_name= 'skill'

urlpatterns = [
    path('admin/', admin.site.urls),
    path('account/', include('account.urls')),
    path('', include('tournament.urls')),
    path('order/', include('order.urls')),
    path('payment/', include('payment.urls')),
    path('notification/', include('notification.urls')),
    path('password/', include('password.urls')),
    path('leaderboard/', include('leaderboard.urls')),
]

urlpatterns += static(settings.STATIC_URL, document_root = settings.STATIC_ROOT)
urlpatterns += static(settings.MEDIA_URL, document_root = settings.MEDIA_ROOT)