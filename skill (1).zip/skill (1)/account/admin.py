from django.contrib import admin
from account.models import Profile, withdrawal

#account App
class ProfileAdmin(admin.ModelAdmin):
    search_fields=['username',] 
    
admin.site.register(Profile,ProfileAdmin)
admin.site.register(withdrawal)


