from django.shortcuts import redirect, render
from django.contrib import messages
from django.contrib.auth.models import User
from django.db.models.signals import post_save
from django.contrib.auth import login,logout, authenticate 
from account.models import Profile,withdrawal
from account.forms import ProfileForm

#profile 
def profile(request):
    try:
        instance = Profile.objects.get(user=request.user)
    except Profile.DoesNotExist:
        instance = None
    if request.method=="POST":
        if instance:
            form = ProfileForm(request.POST, request.FILES, instance=instance)
        else:
            form = ProfileForm(request.POST, request.FILES)
        if form.is_valid():
            obj=form.save(commit=False)
            obj.user=request.user
            obj.save()
            messages.success(request,'Successfully saved your profile')
            return redirect('account:viewprofile')
    else:
        form=ProfileForm(instance=instance)
    context={
        "form":form
    }
    return render (request, 'profile.html', context)    

#profile view
def viewprofile(request):
    return render (request, 'viewprofile.html')

#Login 
def customerlogin(request):
    if request.method =='POST' or request.method =='post':
        username = request.POST['username']
        password = request.POST['password']
        user = authenticate(request, username=username, password= password)
        if user is not None:
            login(request, user)
            messages.success(request, "Welcome Back Chief !")
            return redirect('tournament:index')
        else:            
            messages.error(request, "Email or password incorrect.")
    return render(request, 'login.html')

#Logout
def customerlogout(request):
    logout(request)
    messages.success(request, "Successfully logout")
    return render(request,'login.html')

#Registration
def customerregistration(request):
    if request.method =='POST' or request.method == 'post':
        name =request.POST['name']
        email=request.POST['email']
        password=request.POST['password'] 
        password_confirm=request.POST['password_confirm']
        if password == password_confirm:
            if User.objects.filter(username=name).exists():
                messages.error(request, "Username Already Exist!")
            elif User.objects.filter(email=email).exists():
                messages.error(request, "Email Already Exist!")
            else:
                user =User.objects.create_user(username=name, password=password,email=email,)
                user3 =Profile.objects.create_user(username=name)
                user.save();
                user3.save();
                messages.success(request, "Registration Successfull !")
                return redirect('account:login')
        else:
            messages.error(request, "password and confirm password not matched.!")
    return render(request, 'register.html')

#withdraw
def Withdrawal(request):
    if request.method =='POST' or request.method == 'post':
        ammount =int(request.POST['ammount'])
        accounttype=request.POST['accounttype']
        number=request.POST['number'] 
        if ammount < 50 :
            messages.error(request, "Minimum Withdrawal ammount 50 Taka")
        else:    
            obj = withdrawal()
            obj2=Profile.objects.get(id = request.user.id)
            obj.user=request.user
            obj.ammount=ammount
            obj.account=accounttype
            obj.account_Number=number
            obj.save()
            new = obj2.balance
            if new < 50:
                messages.error(request, "You dont have enough balance .")
            else:    
                newbalance = new - ammount
                obj2.balance=newbalance
                obj2.save()
                messages.success(request, "Withdraw request send successfylly.")
                return render(request, 'withdrawrequest.html')
            return render(request, 'withdraw.html')
        return render(request, 'withdraw.html')
    return render(request, 'withdraw.html')

