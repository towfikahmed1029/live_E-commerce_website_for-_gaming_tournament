from django.contrib import admin

from coupon.models import Coupon

# Register your models here.

admin.site.register(Coupon)
