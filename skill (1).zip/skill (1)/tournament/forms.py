from dataclasses import field
from django.forms.models import ModelForm
from tournament.models import (
    Category, 
    Game, Upcomming
)

class CategoryForm(ModelForm):
    class Meta:
        model = Category
        fields = ('__all__')

class GameForm(ModelForm):
    class Meta:
        model = Game
        fields = ('__all__')
        exclude = ['slug']
        
class UpcommingForm(ModelForm):
    class Meta:
        model = Upcomming
        fields = ('__all__')
        exclude = ['slug']


