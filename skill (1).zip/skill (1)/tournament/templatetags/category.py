from django import template
from tournament.models import Category 

register = template.Library()

@register.filter
def category(user):
    cat = Category.objects.filter(parent=None)
    return cat