from django.db import models
from django.urls import reverse
from django.template.defaultfilters import  slugify
from django.contrib.auth.models import User

#Category
class Category(models.Model):
    name = models.CharField(max_length=50, blank=False, null=False)
    image = models.ImageField(upload_to='category', default='demo/demo.jpg', blank=True, null=True)
    parent = models.ForeignKey('self', related_name='children', on_delete=models.CASCADE, blank=True, null=True)
    created = models.DateTimeField(auto_now_add=True)
    slug = models.SlugField(max_length=250, blank=True, null=True)

    def __str__(self):
        return self.name

    class Meta:
        ordering = ['-created', ]
        verbose_name_plural = 'Categories'
    def get_category_url(self):
        return reverse('tournament:collections', kwargs={'slug': self.slug})

    def save(self, *args, **kwargs):
        if not self.slug:
            self.slug = slugify(self.name)
        return super().save(*args, **kwargs)

#Game 
class Game(models.Model):
    name = models.CharField(max_length=250, blank=False, null=False)
    category = models.ForeignKey(Category, on_delete=models.CASCADE, related_name='category')
    preview_des = models.CharField(max_length=255, verbose_name='Short Descriptions')
    description = models.TextField(max_length=1000, verbose_name='Descriptions')
    roles = models.TextField(max_length=1000, verbose_name='Descriptions')
    image = models.ImageField(upload_to='games', default='demo/demo.jpg', blank=False, null=False)
    price = models.FloatField()
    old_price = models.FloatField(default=0.00, blank=True, null=True)
    is_stock = models.BooleanField(default=True)
    slug = models.SlugField(max_length=250, blank=True, null=True)
    created = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.name

    class Meta:
        ordering = ['-created']

    def get_game_url(self):
        return reverse('tournament:game-details', kwargs={'slug': self.slug})

    def save(self, *args, **kwargs):
        if not self.slug:
            self.slug = slugify(self.name)
        return super().save(*args, **kwargs)

#Game Image
class GameImages(models.Model):
    game = models.ForeignKey(Game, on_delete=models.CASCADE)
    image = models.FileField(upload_to='game_gallery')
    created = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return str(self.game.name)

#upcomming tournament
class Upcomming(models.Model):
    name = models.CharField(max_length=250, blank=False, null=False)
    category = models.ForeignKey(Category, on_delete=models.CASCADE, related_name='category2')
    preview_des = models.CharField(max_length=255, verbose_name='Short Descriptions')
    description = models.TextField(max_length=1000, verbose_name='Descriptions')
    roles = models.TextField(max_length=1000, verbose_name='Descriptions')
    image = models.ImageField(upload_to='upcommings', default='demo/demo.jpg', blank=False, null=False)
    price = models.FloatField()
    slug = models.SlugField(max_length=250, blank=True, null=True)
    created = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.name

    class Meta:
        ordering = ['-created']

    def get_upcomming_url(self):
        return reverse('tournament:upcomming-details', kwargs={'slug': self.slug})

    def save(self, *args, **kwargs):
        if not self.slug:
            self.slug = slugify(self.name)
        return super().save(*args, **kwargs)

#Upcomming Image
class UpcommingImage(models.Model):
    upcomming = models.ForeignKey(Upcomming, on_delete=models.CASCADE)
    image = models.FileField(upload_to='upcomming_gallery')
    created = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return str(self.upcomming.name)




#Variation manager
class VariationManager(models.Manager):
    def sizes(self):
        return super(VariationManager, self).filter(variation='size')

    def colors(self):
        return super(VariationManager, self).filter(variation='color')

VARIATIONS_TYPE = (
    ('size', 'size'),
    ('color', 'color'),
)

# variation value
class VariationValue(models.Model):
    variation = models.CharField(max_length=100, choices=VARIATIONS_TYPE)
    name = models.CharField(max_length=50)
    game = models.ForeignKey(Game, on_delete=models.CASCADE)
    price = models.IntegerField()
    created = models.DateTimeField(auto_now_add=True)
    objects = VariationManager()

    def __str__(self):
        return self.name

# Banner
class Banner(models.Model):
    game = models.ForeignKey(Game, on_delete=models.CASCADE, related_name='banner')
    image = models.ImageField(upload_to='banner')
    is_active = models.BooleanField(default=False)
    created = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.game.name


# Logo
class MyLogo(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    image = models.ImageField(upload_to = 'logo')
    is_active = models.BooleanField(default=False)
    created = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return str(self.image)

# Favicon
class MyFavicon(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    image = models.ImageField(upload_to = 'logo')
    is_active = models.BooleanField(default=False)
    created = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return str(self.image)
