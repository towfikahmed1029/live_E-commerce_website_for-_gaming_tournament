from django.contrib import admin
from tournament.models import (
    Category, Game, GameImages, 
    VariationValue, Banner,
    MyLogo, MyFavicon, Upcomming,
    )
class GameImagesAdmin(admin.StackedInline):
    model = GameImages

class GameAdmin(admin.ModelAdmin):
    inlines = [GameImagesAdmin]
    prepopulated_fields = {'slug': ('name',)}

admin.site.register(Category)
admin.site.register(Upcomming)
admin.site.register(Game, GameAdmin)
admin.site.register(VariationValue)
admin.site.register(Banner)
admin.site.register(MyLogo)
admin.site.register(MyFavicon)
