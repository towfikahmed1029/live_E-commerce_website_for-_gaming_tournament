from django.urls import path
from tournament import views

app_name = 'tournament'
urlpatterns = [
    path('', views.HomeListView.as_view(), name='index'),
    path('game/<slug>/', views.GameDetailView.as_view(), name='game-details'),
    path('upcomming/<slug>/', views.UpcommingDetailView.as_view(), name='upcomming-details'),
    path('games/<slug>/', views.collections, name='collections'),
    path('about/', views.about, name='about'),
]