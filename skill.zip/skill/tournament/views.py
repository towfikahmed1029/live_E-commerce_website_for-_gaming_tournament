from django.http import HttpResponse
from django.shortcuts import render

from django.views.generic import  DetailView, TemplateView

# game models
from tournament.models import Category, Game, GameImages, Banner,Upcomming, UpcommingImage

# Home listview
class HomeListView(TemplateView):
    def get(self, request, *args, **kwargs):
        games = Game.objects.all().order_by('-id')
        upcommings = Upcomming.objects.all().order_by('-id')
        banners = Banner.objects.filter(is_active=True).order_by('-id')[0:3]
        context = {
            'games': games,
            'banners': banners,
            'upcommings': upcommings,
        }
        return render(request, 'index.html', context)

    def post(self, request, *args, **kwargs):
        if request.method == 'post' or request.method == 'POST':
            search_game = request.POST.get('search_upcomming')
            search_upcomming = request.POST.get('search_upcomming')
            games = Game.objects.filter(name__icontains=search_game).order_by('-id')
            upcommings = Upcomming.objects.filter(name__icontains=search_upcomming).order_by('-id')
            context = {
                'games': games,
                'upcommings':upcommings,
            }
            return render(request, 'index.html', context)

#Game details 
class GameDetailView(DetailView):
    model = Game
    template_name = 'product.html'
    context_object_name = 'item'

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['game_images'] = GameImages.objects.filter(game=self.object.id)
        return context

#upcomminf detail view
class UpcommingDetailView(DetailView):
    model = Upcomming
    template_name = 'product2.html'
    context_object_name = 'item2'

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['upcomming_images'] = UpcommingImage.objects.filter(upcomming=self.object.id)
        return context

# Category collection
def collections(request,slug):
    games = Game.objects.filter(category__slug=slug)
    category_name = Category.objects.filter(slug=slug).first()
    context={
        'games2':games,
        'category_name':category_name,
    }
    return render(request, 'product/index.html', context)

#about
def about(request):
    return render (request,'about.html')