from django.contrib import admin
from leaderboard.models import Pubg, Codm, Ff
# Register your models here.
admin.site.register(Pubg)
admin.site.register(Codm)
admin.site.register(Ff)

