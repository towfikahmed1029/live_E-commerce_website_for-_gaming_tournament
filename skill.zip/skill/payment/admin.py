from django.contrib import admin
from payment.models import BillingAddress

admin.site.register(BillingAddress)
