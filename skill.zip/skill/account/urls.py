from django.urls import path
from account import views
from django.contrib.auth import views as auth_views
app_name='account'
urlpatterns = [
    path('registration/', views.customerregistration, name = 'registration'),
    path('login/', views.customerlogin, name = 'login'),
    path('logout/', views.customerlogout, name = 'logout'),
    path('profile/view/', views.viewprofile, name='viewprofile'),
    path('profile/', views.profile, name='profile'),
    path('withdraw/', views.Withdrawal, name='withdraw'),
]
